# `@tiendanube/nexo`

**Nexo** provides tools for communication between an external application and the Nuvemshop administrator.

Full documentation and details are available [here](https://tiendanube.github.io/devhub-apps/en/docs/developer-tools/nexo).

## Installation

```bash
$ npm install @tiendanube/nexo
```

or

```bash
$ yarn add @tiendanube/nexo
```

## Getting Started

To get started, follow the [official documentation](https://tiendanube.github.io/devhub-apps/en/docs/developer-tools/nexo/).

## Actions and Helpers

Here is an overview of the available actions and helpers:

- [Actions](https://tiendanube.github.io/devhub-apps/en/docs/developer-tools/nexo/#actions)
- [Helpers](https://tiendanube.github.io/devhub-apps/en/docs/developer-tools/nexo/#helpers)
