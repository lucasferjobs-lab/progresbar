# Changelog

Nexo provides resources to facilitate communication between an external application and the Nuvemshop administrator. This interaction between the admin and the app is established through the observer pattern, allowing for event subscription and unsubscription.

## 2025-06-30 `1.2.1`

#### 🎉 New features

- **feat**: Added store feature validation and upsell related helpers. ([#29](https://github.com/TiendaNube/admin-nexo/pull/29) by [@matiasmcf](https://github.com/matiasmcf))
  - Added actions and types for upsell related functionality
  - Added comprehensive helpers for upsell related flows
- **feat**: Added fullscreen support for enhanced user experience. ([#28](https://github.com/TiendaNube/admin-nexo/pull/28) by [@cristian-preiti](https://github.com/cristian-preiti))

#### 🐛 Bug fixes

- **fix**: Exported new types for upsell related flows to ensure proper TypeScript support. ([#31](https://github.com/TiendaNube/admin-nexo/pull/31) by [@matiasmcf](https://github.com/matiasmcf))

## 2024-11-01 `1.1.0+`

#### 🎉 New features

- **Admin Info**: Added user ID in store info response for enhanced admin identification. ([#26](https://github.com/TiendaNube/admin-nexo/pull/26) by [@carlos-montes](https://github.com/carlos-montes))
- **Store Info Enhancement**: Added available languages and admin name in store info response. ([#24](https://github.com/TiendaNube/admin-nexo/pull/24) by [@carlos-montes](https://github.com/carlos-montes))
  - Added available languages list
  - Included admin name and roles information  
  - Enhanced store information response with admin details

## 2024-02-01 `0.3.0`

#### 🎉 New features

- **Device Browser Support**: Added new event to open content in device browser for better mobile experience. ([#19](https://github.com/TiendaNube/admin-nexo/pull/19) by [@caio-cares](https://github.com/caio-cares))

## 2024-01-XX - CI/CD Improvements

#### 🔒 Security improvements

- **BREAKING**: Replaced unsafe branch protection disabling with secure automated Pull Request workflow. ([PR](https://github.com/TiendaNube/admin-nexo/pull/TBD))
  - Removed insecure `Branch protection OFF/ON` steps that temporarily disabled repository security
  - Implemented automated PR creation for release updates using `peter-evans/create-pull-request`
  - Added intelligent loop prevention to avoid infinite workflow triggers
  - Enhanced commit message formatting with version information

#### 📚 3rd party library updates

- Updated `actions/checkout` from v2 → v4 for better security and Node.js 20 support
- Updated `actions/setup-node` from v2 → v4 with integrated yarn cache support  
- Updated `peter-evans/create-pull-request` from v5 → v7 for latest features and security fixes
- Updated `rickstaa/action-create-tag` from v1 → v1.7.2
- Updated `8BitJonny/gh-get-current-pr` from v2.2.0 → v3.0.0 for better PR detection
- Updated `ncipollo/release-action` from v1 → v1.18.0
- Updated `martinbeentjes/npm-get-version-action` from @main → v1.3.1 (pinned to stable version)

#### 💡 Others

- Fixed deprecated `--frozen-lockfile` yarn flag, replaced with modern `--immutable` flag
- Corrected GitHub Actions expression syntax for conditional workflow execution
- Added comprehensive documentation in English for workflow components
- Improved workflow reliability with better error handling and status checks
- Enhanced commit message format using conventional commits (`chore: release vX.Y.Z`)

## 2023-09-11 `1.0.0`

#### 🎉 New features

- Changed package build process to use webpack as a build tool. ([#18](https://github.com/TiendaNube/admin-nexo/pull/18) by [@juniorconquista](https://github.com/juniorconquista))
- Added new `publish:next` script to automate release candidate creation. ([#18](https://github.com/TiendaNube/admin-nexo/pull/18) by [@juniorconquista](https://github.com/juniorconquista))
- Added new ErrorBoundary component responsible for capturing unhandled errors and sending a dispatch for the action `ACTION_LOG_ERROR` to the Nexo client. ([#18](https://github.com/TiendaNube/admin-nexo/pull/18) by [@juniorconquista](https://github.com/juniorconquista))
- Added all available action types to the package export. ([#18](https://github.com/TiendaNube/admin-nexo/pull/18) by [@juniorconquista](https://github.com/juniorconquista))
- Added `CHANGELOG.md` file to log all important changes to the package. ([#18](https://github.com/TiendaNube/admin-nexo/pull/18) by [@juniorconquista](https://github.com/juniorconquista))

#### 💡 Others

- Removed files that were sent to the npm package unnecessarily via `.npmignore`. ([#18](https://github.com/TiendaNube/admin-nexo/pull/18) by [@juniorconquista](https://github.com/juniorconquista))
- Adjusted `README.md` to take the user to the complete documentation on the official website. ([#18](https://github.com/TiendaNube/admin-nexo/pull/18) by [@juniorconquista](https://github.com/juniorconquista))


<!-- #### 💡 Others -->
<!-- #### 🎉 New features -->
<!-- #### 🐛 Bug fixes -->
<!-- ####📚 3rd party library updates -->
